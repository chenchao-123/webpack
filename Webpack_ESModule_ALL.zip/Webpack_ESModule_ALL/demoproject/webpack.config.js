//Webpack资源打包器的核心配置文件
module.exports = {
  //0 打包模式
  mode: 'development', //开发模式，打包结果文件不压缩
  //mode: 'production',//产品模式，打包结果文件会压缩
  //1 打包入口文件
  entry: './public/src/js/index.js',
  //2 打包后得到的输出文件
  output: {
    path: __dirname + '/public/dist',//输出文件所在的目录
    filename: 'app.js',//输出文件名
  },
  //3 声明需要用到的加载器——用于打包非js文件，例如ts/css/scss/jpg...
  module: {   //如何打包其它非JS模块
    rules: [    //指定各种不同类型的文件的打包规则
      {
        test: /\.css$/,   //检验是否满足该正则表达式
        use: ['style-loader', 'css-loader']
      },
      {
        test: /\.(jpg|png|gif)$/,
        use: 'url-loader'
      },
      //{}
    ]
  },
  //4 声明需要用到的插件
}