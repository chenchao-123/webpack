//导入其他JS模块中的内容
import  getCompanyName from './util'
//导入其它CSS模块中的内容
import  '../css/base.css'
import  '../css/index.css'
//导入其它图片模块中的内容
import  p20  from  '../img/20.jpg'
import  p40  from  '../img/40.jpg'

function createDiv() {
  var div = document.createElement('div');
  div.classList.add('box');
  div.innerHTML = '版权所有：'+getCompanyName();
  
  let img20 = new Image()
  img20.src = p20  //使用导入的图片对象
  div.appendChild(img20)  //将图片对象追加到DOM树
  
  let img40 = new Image()
  img40.src = p40
  div.appendChild(img40)
  
  return div;   //div内添加完文字和两张图片后返回
}
document.body.appendChild(createDiv());
