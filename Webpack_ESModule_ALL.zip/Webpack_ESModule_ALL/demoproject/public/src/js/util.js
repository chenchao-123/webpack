//导出当前模块中的内容，以供其他模块使用
//Webpack可以识别任何一种导出语法
export  default  function getCompanyName(){
	return 'TEDU.CN';
}